# VitalsSniper PRO: Evidence-Based Website Intelligence & Prospecting Engine

> **In-Browser DOM Recursion, Core Web Vitals Telemetry, Structured Data Profiler, and Consultative Outreach Engine.**  
> Built for web agencies, technical consultants, and performance engineers to diagnose website architectures and generate consultative client proposals.

---

## Why VitalsSniper PRO?

Most website audits rely on generic synthetic tools that generate overwhelming reports without actionable client context.

**VitalsSniper PRO** provides an evidence-based diagnostic workflow:
1. **In-Browser Diagnostics**: Inspect any prospect website directly from your browser toolbar.
2. **Measured Technical Architecture**:
   - **Page Builder Detection**: Identifies Elementor, Divi, WPBakery, GeneratePress, Squarespace, Webflow, Shopify, or Next.js signatures.
   - **DOM Tree Recursion**: Measures total DOM elements, recursion depth (`maxDepth`), and deep branch counts (>15 levels).
   - **Document Payload Analysis**: Measures serialized in-memory markup and network wire transfer sizes.
   - **Mobile Scaling & Viewport**: Identifies missing viewports or scaling restrictions (`user-scalable=no`).
   - **Schema.org Structured Data**: Validates JSON-LD syntax, entity types, and graph hierarchies.
   - **Script Contention**: Profiles external, inline, and third-party script tags.
   - **Server Response Timing**: Measures navigation start to response start (canonical TTFB) with cache detection.
3. **Evidence-Grounded Outreach Generator**: Generates authentic, consultative copy citing exact measured metrics:
   - **Cold Email**: Consultative diagnostic pitch citing observed measurements.
   - **LinkedIn DM**: Brief conversation starter citing specific findings.
   - **Loom Video Script**: 30-second timestamped technical walkthrough outline.
4. **1-Page Executive Teardown Dossier**: Generates a branded, print-ready HTML/PDF audit dossier adhering to professional web audit design tokens.

---

## Quick Start (Install in 30 Seconds)

1. Unzip the downloaded `vitalssniper_pro.zip` file.
2. Open your browser extension manager:
   - **Google Chrome**: `chrome://extensions/`
   - **Brave Browser**: `brave://extensions/`
   - **Microsoft Edge**: `edge://extensions/`
3. Toggle **Developer mode** to **ON** (top-right corner).
4. Click **Load unpacked** in the top-left toolbar.
5. Select the `vitalssniper_extension` directory.
6. Pin **VitalsSniper PRO** to your browser toolbar.
7. Open any target website, click the extension icon, and run the audit.

---

## Client Audit & Outreach Workflow

### Step 1: Open Target Prospect
Navigate to any client or prospect website you want to analyze in your browser.

### Step 2: Run Forensic Scan
Click **VitalsSniper PRO** on your browser toolbar to diagnose:
- Container nesting and tree hierarchy depth
- Document payload size and network transfer bytes
- Viewport scaling directives and touch target dimensions
- Schema.org JSON-LD entity structures

### Step 3: Dispatch Tailored Outreach
Select the **Cold Email**, **LinkedIn DM**, or **Loom Pitch** tab and click **Copy** to dispatch consultative copy citing exact observations.

### Step 4: Export 1-Page Teardown Dossier
Click **1-Page PDF** to generate an executive audit dossier to attach to your client proposal.

---

## Compatibility & License

- **Platform**: Chromium Browsers (Google Chrome, Brave, Microsoft Edge, Arc)
- **Version**: v1.2.0 PRO
- **License**: Single-User Commercial License
